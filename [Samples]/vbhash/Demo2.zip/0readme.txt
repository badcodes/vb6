packing list
------------

visual basic
------------
Demo.exe	' demo program
FMain.frm	' main form
Test.bas	' test driver
CStopWatch.cls	' timer
Demo.vbp	' VB environment

C DLL
-----
vhash.dll	' hash function
vhash.c		' hash source
vhash.dep	' VC junk...
vhash.dsp
vhash.dsw
vhash.mak
vhash.ncb
vhash.opt
vhash.plg

